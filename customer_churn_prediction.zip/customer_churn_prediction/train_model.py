import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

# Load dataset
data = pd.read_csv("dataset/churn.csv")

print("Dataset loaded successfully!")
print("Shape:", data.shape)

# Convert TotalCharges to numeric
data["TotalCharges"] = pd.to_numeric(
    data["TotalCharges"], errors="coerce"
)

# Fill missing values
data["TotalCharges"] = data["TotalCharges"].fillna(
    data["TotalCharges"].median()
)

# Remove customer ID
data = data.drop("customerID", axis=1)

# Convert categorical columns to numbers
label_encoders = {}

for column in data.select_dtypes(include=["object"]).columns:
    if column != "Churn":
        encoder = LabelEncoder()
        data[column] = encoder.fit_transform(data[column])
        label_encoders[column] = encoder

# Encode target column
data["Churn"] = data["Churn"].map({
    "Yes": 1,
    "No": 0
})

# Separate features and target
X = data.drop("Churn", axis=1)
y = data["Churn"]

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Create model
model = RandomForestClassifier(
    n_estimators=200,
    random_state=42
)

# Train model
model.fit(X_train, y_train)

# Make predictions
predictions = model.predict(X_test)

# Evaluate
accuracy = accuracy_score(y_test, predictions)

print("\nModel Training Completed!")
print("Accuracy:", round(accuracy * 100, 2), "%")

print("\nClassification Report:")
print(classification_report(y_test, predictions))

# Save model
joblib.dump(model, "churn_model.pkl")

# Save feature columns
joblib.dump(list(X.columns), "feature_columns.pkl")

# Save encoders
joblib.dump(label_encoders, "label_encoders.pkl")

print("\nModel saved successfully!")