import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

from sklearn.metrics import (
    roc_auc_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report
)


# ============================================================
# 1. LOAD DATASET
# ============================================================

data = pd.read_csv("dataset/churn.csv")

print("========================================")
print("CUSTOMER CHURN PREDICTION")
print("========================================")

print("\nDataset loaded successfully!")
print("Dataset shape:", data.shape)


# ============================================================
# 2. BASIC CLEANING
# ============================================================

# Convert TotalCharges to numeric
data["TotalCharges"] = pd.to_numeric(
    data["TotalCharges"],
    errors="coerce"
)

# Remove customer ID
if "customerID" in data.columns:
    data = data.drop("customerID", axis=1)


# ============================================================
# 3. CREATE TARGET VARIABLE
# ============================================================

data["Churn"] = data["Churn"].map({
    "Yes": 1,
    "No": 0
})

# Remove rows where target is missing
data = data.dropna(subset=["Churn"])


# ============================================================
# 4. FEATURE ENGINEERING
# ============================================================

# Average monthly spending based on total charges and tenure
data["AverageMonthlySpend"] = np.where(
    data["tenure"] > 0,
    data["TotalCharges"] / data["tenure"],
    data["MonthlyCharges"]
)

# Support-risk feature
if "TechSupport" in data.columns:
    data["NoTechSupport"] = (
        data["TechSupport"] == "No"
    ).astype(int)


# ============================================================
# 5. SEPARATE FEATURES AND TARGET
# ============================================================

X = data.drop("Churn", axis=1)
y = data["Churn"]


print("\nTarget distribution:")
print(y.value_counts())

print("\nChurn percentage:")
print((y.mean() * 100).round(2), "%")


# ============================================================
# 6. IDENTIFY COLUMN TYPES
# ============================================================

numeric_features = X.select_dtypes(
    include=["int64", "float64"]
).columns.tolist()

categorical_features = X.select_dtypes(
    include=["object"]
).columns.tolist()


print("\nNumerical columns:")
print(numeric_features)

print("\nCategorical columns:")
print(categorical_features)


# ============================================================
# 7. PREPROCESSING
# ============================================================

numeric_pipeline = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ]
)

categorical_pipeline = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        (
            "encoder",
            OneHotEncoder(
                handle_unknown="ignore",
                sparse_output=False
            )
        )
    ]
)

preprocessor = ColumnTransformer(
    transformers=[
        ("numeric", numeric_pipeline, numeric_features),
        ("categorical", categorical_pipeline, categorical_features)
    ]
)


# ============================================================
# 8. TRAIN / TEST SPLIT
# ============================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\nTraining samples:", len(X_train))
print("Testing samples:", len(X_test))


# ============================================================
# 9. DEFINE MODELS
# ============================================================

models = {

    "Logistic Regression": LogisticRegression(
        max_iter=1000,
        class_weight="balanced",
        random_state=42
    ),

    "Random Forest": RandomForestClassifier(
        n_estimators=300,
        max_depth=12,
        min_samples_split=5,
        class_weight="balanced",
        random_state=42
    ),

    "XGBoost": XGBClassifier(
        n_estimators=300,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        eval_metric="logloss",
        random_state=42
    )
}


# ============================================================
# 10. TRAIN AND COMPARE MODELS
# ============================================================

results = {}

trained_pipelines = {}

print("\n========================================")
print("MODEL COMPARISON")
print("========================================")

for name, model in models.items():

    print(f"\nTraining {name}...")

    pipeline = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("model", model)
        ]
    )

    pipeline.fit(X_train, y_train)

    # Probability predictions
    probabilities = pipeline.predict_proba(X_test)[:, 1]

    # Class predictions
    predictions = (probabilities >= 0.5).astype(int)

    # Metrics
    roc_auc = roc_auc_score(
        y_test,
        probabilities
    )

    precision = precision_score(
        y_test,
        predictions,
        zero_division=0
    )

    recall = recall_score(
        y_test,
        predictions,
        zero_division=0
    )

    f1 = f1_score(
        y_test,
        predictions,
        zero_division=0
    )

    results[name] = {
        "ROC-AUC": roc_auc,
        "Precision": precision,
        "Recall": recall,
        "F1": f1
    }

    trained_pipelines[name] = pipeline

    print(f"ROC-AUC   : {roc_auc:.4f}")
    print(f"Precision : {precision:.4f}")
    print(f"Recall    : {recall:.4f}")
    print(f"F1 Score  : {f1:.4f}")


# ============================================================
# 11. DISPLAY MODEL COMPARISON
# ============================================================

results_df = pd.DataFrame(results).T

print("\n========================================")
print("FINAL MODEL COMPARISON")
print("========================================")

print(results_df.round(4))


# ============================================================
# 12. SELECT MODEL BASED ON ROC-AUC
# ============================================================

best_model_name = results_df["ROC-AUC"].idxmax()

best_model = trained_pipelines[
    best_model_name
]

print("\n========================================")
print("SELECTED MODEL")
print("========================================")

print("Model:", best_model_name)
print(
    "ROC-AUC:",
    round(
        results_df.loc[
            best_model_name,
            "ROC-AUC"
        ],
        4
    )
)


# ============================================================
# 13. DETAILED CLASSIFICATION REPORT
# ============================================================

best_probabilities = best_model.predict_proba(
    X_test
)[:, 1]

best_predictions = (
    best_probabilities >= 0.5
).astype(int)

print("\n========================================")
print("CLASSIFICATION REPORT")
print("========================================")

print(
    classification_report(
        y_test,
        best_predictions,
        target_names=["No Churn", "Churn"]
    )
)


# ============================================================
# 14. SAVE BEST MODEL
# ============================================================

joblib.dump(
    best_model,
    "churn_model.pkl"
)

print("\nBest model saved as:")
print("churn_model.pkl")


# ============================================================
# 15. SAVE FEATURE INFORMATION
# ============================================================

joblib.dump(
    list(X.columns),
    "feature_columns.pkl"
)

print("Feature columns saved as:")
print("feature_columns.pkl")


# ============================================================
# FINISHED
# ============================================================

print("\n========================================")
print("TRAINING COMPLETED SUCCESSFULLY!")
print("========================================")