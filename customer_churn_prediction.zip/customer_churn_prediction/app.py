import streamlit as st
import pandas as pd
import joblib


# -----------------------------
# Page Configuration
# -----------------------------
st.set_page_config(
    page_title="Customer Churn Prediction",
    page_icon="📊",
    layout="wide"
)

# -----------------------------
# Load Model and Files
# -----------------------------
model = joblib.load("churn_model.pkl")
feature_columns = joblib.load("feature_columns.pkl")
label_encoders = joblib.load("label_encoders.pkl")

# Load original dataset
data = pd.read_csv("dataset/churn.csv")

# Convert TotalCharges to numeric
data["TotalCharges"] = pd.to_numeric(
    data["TotalCharges"],
    errors="coerce"
)

data["TotalCharges"] = data["TotalCharges"].fillna(
    data["TotalCharges"].median()
)

# -----------------------------
# Header
# -----------------------------
st.title("📊 Customer Churn Prediction")
st.write(
    "Predict whether a customer is likely to leave the service "
    "using Machine Learning."
)

st.divider()

# -----------------------------
# Dashboard Statistics
# -----------------------------
total_customers = len(data)
churned_customers = (data["Churn"] == "Yes").sum()
churn_rate = (churned_customers / total_customers) * 100

col1, col2, col3 = st.columns(3)

with col1:
    st.metric(
        "Total Customers",
        total_customers
    )

with col2:
    st.metric(
        "Churned Customers",
        churned_customers
    )

with col3:
    st.metric(
        "Churn Rate",
        f"{churn_rate:.2f}%"
    )

st.divider()

# -----------------------------
# Customer Input
# -----------------------------
st.subheader("👤 Customer Information")

input_data = {}

# Create columns for input fields
col1, col2, col3 = st.columns(3)

for i, feature in enumerate(feature_columns):

    # Select which column to use
    current_col = [col1, col2, col3][i % 3]

    with current_col:

        # Categorical feature
        if feature in label_encoders:

            options = list(label_encoders[feature].classes_)

            input_data[feature] = st.selectbox(
                feature,
                options
            )

        # Numerical feature
        else:

            if feature == "SeniorCitizen":
                input_data[feature] = st.selectbox(
                    feature,
                    [0, 1]
                )

            elif feature == "tenure":
                input_data[feature] = st.number_input(
                    "Tenure (months)",
                    min_value=0,
                    max_value=100,
                    value=12
                )

            elif feature == "MonthlyCharges":
                input_data[feature] = st.number_input(
                    "Monthly Charges",
                    min_value=0.0,
                    value=70.0,
                    step=1.0
                )

            elif feature == "TotalCharges":
                input_data[feature] = st.number_input(
                    "Total Charges",
                    min_value=0.0,
                    value=840.0,
                    step=10.0
                )

            else:
                input_data[feature] = st.number_input(
                    feature,
                    value=0.0
                )

# -----------------------------
# Prediction Button
# -----------------------------
st.divider()

if st.button(
    "🔮 Predict Customer Churn",
    use_container_width=True
):

    # Create dataframe
    input_df = pd.DataFrame(
        [input_data]
    )

    # Encode categorical features
    for feature, encoder in label_encoders.items():

        input_df[feature] = encoder.transform(
            input_df[feature]
        )

    # Make sure columns are in correct order
    input_df = input_df[feature_columns]

    # Prediction
    prediction = model.predict(input_df)[0]

    # Probability
    probability = model.predict_proba(input_df)[0][1]

    st.divider()

    # -----------------------------
    # Display Result
    # -----------------------------

    st.subheader("📌 Prediction Result")

    result_col1, result_col2 = st.columns(2)

    with result_col1:

        if prediction == 1:

            st.error("🔴 Customer is likely to CHURN")

        else:

            st.success("🟢 Customer is likely to STAY")

    with result_col2:

        st.metric(
            "Churn Probability",
            f"{probability * 100:.2f}%"
        )

    # Risk level
    if probability >= 0.70:

        st.error(
            "🚨 Risk Level: HIGH"
        )

        st.write(
            "This customer has a high predicted probability "
            "of leaving the service."
        )

    elif probability >= 0.40:

        st.warning(
            "⚠️ Risk Level: MEDIUM"
        )

        st.write(
            "This customer has a moderate predicted probability "
            "of leaving the service."
        )

    else:

        st.success(
            "✅ Risk Level: LOW"
        )

        st.write(
            "This customer has a relatively low predicted "
            "probability of leaving the service."
        )

    # Suggested action
    st.subheader("💡 Suggested Review")

    if probability >= 0.70:

        st.write(
            "Review the customer's contract, service usage, "
            "billing history, and support interactions."
        )

    elif probability >= 0.40:

        st.write(
            "Monitor the customer and review recent service "
            "or billing changes."
        )

    else:

        st.write(
            "No immediate retention action is indicated "
            "by the model."
        )

# -----------------------------
# Footer
# -----------------------------
st.divider()

st.caption(
    "Customer Churn Prediction System | "
    "Machine Learning Project"
)